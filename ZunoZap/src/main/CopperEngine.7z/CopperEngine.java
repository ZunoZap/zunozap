package com.zunozap.impl;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.zunozap.Browser;
import com.zunozap.Engine;
import com.zunozap.copper.CopperRenderer;

import javafx.embed.swing.SwingNode;

public class CopperEngine implements Engine {

    private CopperRenderer b;
    private static Browser a;
    private SwingNode s;

    public CopperEngine() {
        swing(()-> a = null == a ? new Browser() : a);
        b = new CopperRenderer(new JTextField(), 0);
        s = new SwingNode() {
            @Override public double minWidth(double a) {return 0;}
            @Override public double prefWidth(double a) {return 90;}
            @Override public double maxWidth(double a) {return Integer.MAX_VALUE;}
            @Override public double minHeight(double a) {return 0;}
            @Override public double prefHeight(double a) {return 90;}
            @Override public double maxHeight(double a) {return Integer.MAX_VALUE;}
        };
        swing(()->s.setContent(b));
    }
    
    public void swing(Runnable r) {
        SwingUtilities.invokeLater(r);
    }

    @Override
    public javafx.scene.Node getComponent() {
        return s;
    }

    @Override
    public Object getImplEngine() {
        return b;
    }

    @Override
    public void load(String url) {
        swing(() -> {
            try {
                a.setTitle(url);b.load(url);
            } catch (Exception e) {e.printStackTrace();}
        });
    }

    @Override
    public void loadHTML(String html) {
    }

    @Override
    public String getTitle() {
        return b.title;
    }

    @Override
    public String getURL() {
        return a.getTitle();
    }

    @Override
    public void stop() {
        b.removeAll();
    }

    @Override
    public void js(boolean bo) {}

    @Override
    public String getUserAgent() {
        return "Mozilla/5.0 (Windows 10) Copper/1.0";
    }

    @Override
    public void history(int history) {}

}